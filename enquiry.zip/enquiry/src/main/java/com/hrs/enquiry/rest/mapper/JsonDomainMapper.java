package com.hrs.enquiry.rest.mapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JsonDomainMapper {

    private JsonDomainMapper() {}




}
