package com.hrs.enquiry.repository;

import com.hrs.enquiry.model.GuestDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface GuestDetailsRepository extends JpaRepository<GuestDetails, String> {

    Optional<GuestDetails> findByRoomNoAndStatus(String roomNo, String status);

    List<GuestDetails> findByStatus(String status);
}
