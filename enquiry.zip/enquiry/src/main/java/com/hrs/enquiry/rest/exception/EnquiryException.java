package com.hrs.enquiry.rest.exception;

import lombok.*;

public class EnquiryException extends RuntimeException{

    public EnquiryException(String message){
        super(message);
    }

    public EnquiryException(String message, Throwable error){
        super(message, error);
    }

}
