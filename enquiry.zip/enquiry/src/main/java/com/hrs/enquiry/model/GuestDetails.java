package com.hrs.enquiry.model;


import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Table(name = "guest_details")
@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GuestDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "GUEST_ID")
    private long guestId;

    @Column (name = "guest_name")
    private String guestName;

    @Column (name = "no_of_guests")
    private int noOfGuests;

    @Column (name = "room_no")
    private String roomNo;

    @Column (name = "CHECK_IN_TIME")
    private LocalDateTime checkInTime;

    @Column (name = "status")
    private String status;

    @Column (name = "type_of_room")
    private String typeOfRoom;

    @Column (name = "CHECK_OUT_TIME")
    private LocalDateTime checkOutTime;

    @Column (name = "parcel_details_json")
    private String parcelDetailsJson;
}
