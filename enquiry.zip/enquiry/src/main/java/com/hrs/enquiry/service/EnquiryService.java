package com.hrs.enquiry.service;

import com.hrs.enquiry.model.GuestDetails;
import com.hrs.enquiry.rest.json.ParcelDetails;

import java.util.List;

public interface EnquiryService {

    GuestDetails insert(GuestDetails guestDetails);

    List<GuestDetails> findAll();

    GuestDetails update(List<ParcelDetails> parcelReq, String roomNo);

    GuestDetails updateWhileCheckOut(String roomNo);

}